# MOP-USSEIN — Site GitHub

Site web statique pour la Licence Management des Organisations Paysannes (L1, L2, L3), les étudiants et les nouveaux bacheliers.

## Fichiers
- `index.html` : accueil
- `styles.css` : design responsive
- `script.js` : menu mobile + recherche des matières
- `pages/` : pages du site
- `assets/` : logo, documentaire et images

## Ajouter les médias
Copier :
- logo officiel → `assets/logo-mop.png`
- documentaire → `assets/documentaire-mop.mp4`
- affiche vidéo (optionnel) → `assets/poster-documentaire.jpg`

## GitHub Pages
1. Créer un dépôt GitHub, par exemple `mop-ussein`.
2. Importer tous les fichiers.
3. `Settings` → `Pages`.
4. `Deploy from a branch`.
5. Choisir `main` et `/ (root)`.
6. Enregistrer.

## À personnaliser avant publication
- coordonnées officielles ;
- réseaux sociaux ;
- photos réelles ;
- actualités réelles ;
- calendrier/emploi du temps ;
- liens officiels d'orientation et d'inscription ;
- documentaire final.

## Évolution vers un vrai portail étudiant
GitHub Pages ne fournit pas à lui seul une base de données ou une authentification privée. Pour L1/L2/L3, ajouter ensuite un backend et une authentification (par exemple Supabase/Firebase ou une API dédiée), avec gestion des rôles étudiant/enseignant/admin.
